import pickle
import pandas as pd
import numpy as np
import sys

from flaml import AutoML

if __name__ == '__main__':
    filepath = sys.argv[1]
    X = pd.read_csv(filepath, quotechar='"', skipinitialspace=True)
    with open('flaml-model.p', 'rb') as file:
        automl2 = pickle.load(file)

    predicted_y = automl2.predict(X)
    predicted_y = np.reshape(predicted_y, (-1,1))
    print(predicted_y)